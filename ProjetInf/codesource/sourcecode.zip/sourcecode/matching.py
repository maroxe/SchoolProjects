import numpy as np
import pydot
from collections import Counter
from operator import itemgetter

import ga

# Graph examples
def graph1(n):
    edges = [ (i,j) if i < j else (j,i) for i,j in np.random.randint(n, size=(3*n, 2)) if i != j ]
    #make edges unique
    return map(itemgetter(0), Counter(edges).items())
 
def graph2(n):
    return [(i, i+1) if i+1 < n else (n-1, 0) for i in range(n)]

# draw graph to an image file
def draw_graph(edges, vertices, M=None, image='graph.png'):
    if not M:
        M = [0] * len(edges)
        
    graph = pydot.Dot(graph_type='graph')
    
    for v in vertices: 
        graph.add_node(pydot.Node("Node %d" % v))
        
    for i, (e,f) in enumerate(edges):
        color = "red" if  M[i] else "black"
        edge = pydot.Edge("Node %d" % e, "Node %d" % f, color=color)
        graph.add_edge(edge)
           
    graph.write_png(image, )

def deg(M):
    deg_m = np.zeros(n)
    for i, (e, f) in enumerate(edges):
        if M[i]:
            deg_m[e] += 1
            deg_m[f] += 1
    return sum([max(0, d-1) for d in deg_m])

def fitness(M):
    return sum(M) - m * deg(M)

ea_algo = ga.EA(fitness=fitness)


n = 8
vertices = list(range(n))
edges = graph1(n)
m = len(edges)

x_init = np.random.random_integers(0, 1, size=m) 
max_graph = ea_algo.run(n, x_init=x_init, offspring_size=3, 
                        n_generations=1000)

draw_graph(edges, vertices, M=max_graph, image='resources/matching/random_graph_matching.png')
draw_graph(edges, vertices, image='resources/matching/random_graph.png')



