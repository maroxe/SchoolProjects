import numpy as np
import pydot 
import random

graph1 = [[False, True, False, True, True, False, False, True], [True, False, True, False, True, True, False, False], [False, True, False, True, False, True, True, False], [True, False, True, False, False, False, True, True], [True, True, False, False, False, False, False, False], [False, True, True, False, False, False, False, False], [False, False, True, True, False, False, False, False], [True, False, False, True, False, False, False, False]]
graph2 = [
            [True, True, True, True, True],
            [True, True, False, True, False],
            [True, False, True, True, False],
            [True, True, True, True, True],
            [True, False, False, True, True],
           ]

graph3 = [
[1,    0,   1,    1,    1,    0,    1,    0],
[0,    1,   1,    1,    1,     0,    0,    1],
[0,    1,   1,    1,    1,    0,    0,    1],
[1,    0,   1,    1,    1,    0,    1,    0],
[0,    0,   1,    1,    1,    0,    0,    0],
[1,    1,   1,    1,    1,    1,    1,    1],
[1,    1,   1,    1,    1,    1,    1,    1],
[1,    1,   1,    1,    1,    1,    1,    1],
]

def graph_cycle(n):
    edges = np.zeros((n, n))
    for i in range(n):
        edges[i][i] = False
        j = i+1 if i < n-1 else 0
        edges[i][j] = True
        edges[j][i] = True
    return edges

def graph3friend(n):
    edges = np.zeros((n, n))
    vertices = range(n)
    for i in range(n):
        friends = random.sample(vertices, 3)
        edges[i][i] = False
        for f in friends:
            edges[i][f] = True
            edges[f][i] = True
    make_eulerian(edges)
    return edges

def graph_triangle(n):
    edges = np.zeros((2*n+1, 2*n+1))
    for i in range(1, (n+1)):
        edges[2*i][2*i-1], edges[2*i-1][2*i] = 1, 1
        edges[2*i][2*i-2], edges[2*i-2][2*i] = 1, 1
        edges[2*i-1][2*i-2], edges[2*i-2][2*i-1] = 1, 1
    return edges

def make_eulerian(edges):
    n = len(edges)
    i = 0
    j = 0
    while i < n:
        deg = sum(edges[i])
        if deg % 2 != 0:
            for j in range(i+1, n):
                if sum(edges[j]) % 2 != 0:
                    edges[i][j] = not edges[i][j] 
                    edges[j][i] = not edges[j][i] 
            i = j+1
        else:
            i += 1
    
def draw_graph(edges, image='graph.png', sub_graph=None, path=None):
    if sub_graph == None:
        sub_graph = [1] * len(edges)
        
    graph = pydot.Dot(graph_type='digraph', rankdir='LR')
    
    if path:
        s0 = path[0]
        for i, s in enumerate(path[1:]):
            graph.add_edge(pydot.Edge("Node %d" % s0, "Node %d" % s,
                                  #fontsize="15.0", color="blue"))
                                  label='%d' % (i+1), fontsize="15.0", color="blue"))
            edges[s0][s] = False
            edges[s][s0] = False
            s0 = s
            
            
    for i in range(len(edges)):
        for j in range(i):
            if edges[i][j]:
                edge = pydot.Edge("Node %d" % i, "Node %d" % j)
                graph.add_edge(edge)
            elif sub_graph[i]:
                graph.add_node(pydot.Node("Node %d" % i))

    graph.write_png(image, )
    #graph.write_png(image, prog='neato')