from random import choice

from pyalgotrade import strategy
from pyalgotrade.barfeed import yahoofeed
from pyalgotrade.tools import yahoofinance

import ga
import rules

filename = "resources/finance/orcl.csv"
instrument = "ORCL"

def download_history(stock, year, filename):
    yahoofinance.download_daily_bars(stock, year, filename)

class MyStrategy(strategy.BacktestingStrategy):
    def __init__(self, feed, instrument, rule):
        strategy.BacktestingStrategy.__init__(self, feed, 1000)
        self.setUseAdjustedValues(True)
        
        self.__feed = feed
        self.__ticks = feed[instrument].getAdjCloseDataSeries()

        self.__instrument = instrument
        self.__position = None
        self.__rule = rule
    
 
      
    def getSMA(self, period):
        return sum(self.__ticks[-period:]) / period

        
    def getMax(self, period):
        return max(self.__ticks[-period:])
        
    def onEnterOk(self, position):
        execInfo = position.getEntryOrder().getExecutionInfo()
        #self.info('BUY at %.2f' % execInfo.getPrice())
            
    def onEnterCanceled(self, position):
        self.debug('Enter canceled')
        self.__position = None
    
    def onExitOk(self, position):
        execInfo = position.getExitOrder().getExecutionInfo()
        #self.info('SELL at %.2f' % execInfo.getPrice())
        self.__position = None
        
    def onExitCanceled(self, position):
        self.debug('Exit canceled')
        self.__position.exitMarket()
        
    def onBars(self, bars):
        if self.__position is None:
            if self.__rule.eval():
                self.__position = self.enterLong(self.__instrument, 10, True)
        elif not self.__rule.eval():
            self.__position.exitMarket()

n = 10

    
def fitness(rule):
    feed = yahoofeed.Feed()
    feed.addBarsFromCSV(instrument, filename)
    strat = MyStrategy(feed, instrument, rule)
    rules.strategy = strat
    strat.run()
    r = strat.getResult()-1000
    return r

def mutation(l, x):
    x_mut = x.copy()
    for _ in range(l*5):
        node = choice(x_mut.nodes()).parent
        if node == None:
            x_mut = rules.generate_bool(n)
        else:
            node.mutate_child(3)
    return x_mut.simplify()

def crossover(c, x, xx):
    x_cross = x.copy()
    #for _ in range(int(len(x) * c) + 1):
    for _ in range(int(c*5)):
        node_to_replace = choice(x_cross.nodes())
        parent = node_to_replace.parent
        
        if parent == None:
            return rules.generate_bool(n)
            
        same_type_nodes = filter(lambda n: n.type() == node_to_replace.type(), xx.nodes())
        try:
            node_to_add = choice(same_type_nodes).copy()
            parent.replace_child(node_to_replace, node_to_add)
        except IndexError:
            #print 'warning no node matches'
            pass
    return x_cross.simplify()
 
x_init = rules.generate_bool(n)
ea_algo = ga.EA(fitness=fitness, mutation=mutation, crossover=crossover)
best_x = ea_algo.run(n, x_init, offspring_size=8, n_generations=10)
rules.draw_tree(best_x, 'strategy.svg')
print best_x.to_str()
print 'best = ', fitness(best_x)
 

