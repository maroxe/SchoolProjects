import random
import graph
from copy import deepcopy
import numpy as np

import ga

# Matches e and f
def match(Mv, e, f):
    Mv[e] = f
    Mv[f] = e
    
def find_match_and_remove(Mv, e):
    # Look for an edge f matched to e
    f = Mv.pop(e, None)
    # Remove the matching (if possible)
    if f is not None:
        del Mv[f]
    return f


def mutation(l, x):
    x_mut = deepcopy(x)
    for _ in range(l):  
        # Choose a random vertex v
        v = random.randint(0, n-1)
        Mv = x_mut[v]
        deg_v = sum([edges[v][i] for i in vertices if i != v])
        if deg_v < 2:
            raise Exception('The graph is not eulerian because vertex %d has deg = %d' % (v, deg_v))
        # if deg(v) == 2, a trivial perfect matching is [ (i, j) ]
        elif deg_v == 2:
            i, j = [w for w in vertices if edges[v][w] and v != w]
            match(Mv, i, j)
        else:
            # Choose a random edge e incident to v, 
            e = random.choice([i for i in vertices if i != v and edges[v][i]])
            # See if it is matched. If it's the case, remove the match
            f = find_match_and_remove(Mv, e)
            
            # Same thing for (ee, ff)
            ee = random.choice([i for i in vertices if (not i in[ v, e, f]) and edges[v][i]])
            ff = find_match_and_remove(Mv, ee)
            
            # match (e, ee) and (f, ff) if possible
            match(Mv, e, ee)
            if f and ff:
                match(Mv, f, ff)
                
    return x_mut

def fitness(x):
    global i
    i += 1
    k = count_walks(x)
    cycles_penality = nb_edges - sum(map(lambda Mv: len(Mv), x))/2  
    return  - cycles_penality  - (k-1)

def count_walks(x):
    # k is the number of independant paths induced by the matching x
    k = 0
    xx = deepcopy(x)
    # Each vertex v, we follow and remove the path induced by the matching
    for v in vertices:
        while len(xx[v]) > 0:
            e, f = xx[v].popitem()
            del xx[v][f]
            is_cycle = False
            # follow the path in both directions
            for i, j in [ (e, f), (f, e)]:
                # if we have found a cycle, there is no need
                # to follow the path in the opposite direction
                if is_cycle: break
                
                # s is the current vertex, i the precedent, and j the next
                # i -> s -> j
                i, s = v, j
                while j != None:
                    j = find_match_and_remove(xx[s], i)
                    i, s = s, j
                # we have found a cycle if the last vertex visited == v
                is_cycle = (i == v)    
            k += 1
    return k

# Reconstruct the tour induced by x
def reconstruct_tour(x, start=0):
    xx = deepcopy(x)
    if len(xx[start]) == 0: return []
    
    # v is the current vertex, i the precedent, and j the next
    # i -> v -> j
    i, j = xx[start].popitem()
    path = [i, start, j]
    i, v = start, j
    while j is not None:
        j = find_match_and_remove(xx[v], i)
        path.append(j)
        i, v = v, j
    return path[:-2]    

def poisson_distribution(n, p):
    return 1+np.random.poisson(1)    
   
ea_algo = ga.EA(fitness=fitness, mutation=mutation, l_distribution=poisson_distribution)


n = 9

edges = graph.graph_triangle(n/2)
vertices = list(range(n))
nb_edges = sum ([edges[i][j] for i in range(n) for j in range(n) if i != j]) / 2
results = []
x_init = [ {} for _ in range(n)]
best_x = ea_algo.run(n=n, x_init=x_init, offspring_size=3, n_generations=100000, max_fitness=0)

print 'fitness = ', fitness(best_x)
path = reconstruct_tour(best_x)
print 'path: ', path
graph.draw_graph(edges, 'resources/euler/graph_cycle.png', path=path)




