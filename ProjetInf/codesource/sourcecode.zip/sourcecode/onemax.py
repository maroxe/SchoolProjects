import ga
import numpy as np

def fitness(x):
    return sum(x)

n = 100
ea_algo = ga.EA(fitness=fitness)
x_init = np.random.random_integers(0, 1, size=n) 
x = ea_algo.run(n, x_init, offspring_size=4, n_generations=100000, 
            max_fitness=n)
print x
    
